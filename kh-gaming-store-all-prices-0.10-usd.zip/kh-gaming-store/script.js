/* KH GAMING STORE
   CONFIG: Change the prices, QR image URLs, Telegram username and demo PIN below.
   This is a front-end demo. Orders and settings are saved only in this browser using localStorage.
   Do not use this demo PIN as real security. Add a trusted backend before handling real customer data.
*/
const CONFIG = {
  storeName: "KH GAMING STORE",
  adminPin: "2468", // DEMO ONLY - NOT SECURE
  telegramUsername: "YOUR_TELEGRAM", // e.g. khgamingstore (no @)
  paymentNote: "KH GAMING STORE",
  qr: { phillip: "assets/phillip-qr.jpg" }, // Public path to the shop QR image
  packages: {
    ff: [
      {id:"ff1", name:"100 Diamonds", detail:"Free Fire", price:0.1},
      {id:"ff2", name:"210 Diamonds", detail:"Free Fire", price:0.1},
      {id:"ff3", name:"530 Diamonds", detail:"Free Fire", price:0.1},
      {id:"ff4", name:"1080 Diamonds", detail:"Free Fire", price:0.1}
    ],
    ml: [
      {id:"ml1", name:"86 Diamonds", detail:"Mobile Legends", price:0.1},
      {id:"ml2", name:"172 Diamonds", detail:"Mobile Legends", price:0.1},
      {id:"ml3", name:"257 Diamonds", detail:"Mobile Legends", price:0.1},
      {id:"ml4", name:"706 Diamonds", detail:"Mobile Legends", price:0.1}
    ],
    rb: [
      {id:"rb1", name:"80 Robux", detail:"Roblox", price:0.1},
      {id:"rb2", name:"400 Robux", detail:"Roblox", price:0.1},
      {id:"rb3", name:"800 Robux", detail:"Roblox", price:0.1},
      {id:"rb4", name:"Gift Card", detail:"Roblox • Confirm before payment", price:0.1}
    ]
  }
};

const GAME_NAMES = {ff:"Free Fire", ml:"Mobile Legends", rb:"Roblox"};
const STORAGE_ORDERS = "khgs_orders_v1";
const STORAGE_SETTINGS = "khgs_settings_v1";
let currentGame = "ff";
let selectedPackage = CONFIG.packages.ff[0];
let currentOrderId = null;
let toastTimer;

const $ = id => document.getElementById(id);
const formatPrice = amount => "$" + Number(amount).toFixed(2);
const safe = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function getSettings(){
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_SETTINGS)||"{}");
    return {
      qr: {...CONFIG.qr, ...(saved.qr||{})},
      telegramUsername: saved.telegramUsername ?? CONFIG.telegramUsername,
      paymentNote: saved.paymentNote ?? CONFIG.paymentNote
    };
  } catch {
    return {qr:CONFIG.qr, telegramUsername:CONFIG.telegramUsername, paymentNote:CONFIG.paymentNote};
  }
}
function saveSettings(settings){ localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings)); }
function getOrders(){ try{return JSON.parse(localStorage.getItem(STORAGE_ORDERS)||"[]");}catch{return [];} }
function saveOrders(orders){ localStorage.setItem(STORAGE_ORDERS, JSON.stringify(orders)); }
function showToast(message){
  const toast=$("toast"); toast.textContent=message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove("show"),2600);
}
function renderPackages(){
  const packages=CONFIG.packages[currentGame];
  $("packageTitle").textContent=GAME_NAMES[currentGame]+(currentGame==="rb"?" Packages":" Diamonds");
  $("packageCount").textContent=String(packages.length).padStart(2,"0")+" PACKS";
  $("packageGrid").innerHTML=packages.map(p=>`
    <button type="button" class="package-card ${p.id===selectedPackage.id?"selected":""}" data-package="${safe(p.id)}">
      <span class="diamond-icon">${currentGame==="rb"?"▧":"◆"}</span>
      <span><b>${safe(p.name)}</b><small>${safe(p.detail)}</small><span class="package-price">${formatPrice(p.price)}</span></span>
      ${p.id===selectedPackage.id?'<span class="package-check">✓</span>':""}
    </button>`).join("");
  $("sumGame").textContent=GAME_NAMES[currentGame];
  $("sumPackage").textContent=selectedPackage.name;
  $("sumPrice").textContent=formatPrice(selectedPackage.price);
  $("zoneWrap").classList.toggle("hidden",currentGame!=="ml");
}
document.querySelectorAll(".game-card").forEach(button=>{
  button.addEventListener("click",()=>{
    currentGame=button.dataset.game;
    selectedPackage=CONFIG.packages[currentGame][0];
    document.querySelectorAll(".game-card").forEach(b=>b.classList.toggle("active",b===button));
    renderPackages();
  });
});
$("packageGrid").addEventListener("click",e=>{
  const button=e.target.closest("[data-package]"); if(!button)return;
  const p=CONFIG.packages[currentGame].find(x=>x.id===button.dataset.package); if(!p)return;
  selectedPackage=p; renderPackages();
});
function makeOrderId(){ return "KHGS-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(); }
function telegramUrl(text){
  const user=(getSettings().telegramUsername||"").replace(/^@/,"").trim();
  if(!user || user==="YOUR_TELEGRAM") return "";
  return "https://t.me/"+encodeURIComponent(user)+"?text="+encodeURIComponent(text);
}
$("orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const playerId=$("playerId").value.trim();
  const zoneId=$("zoneId").value.trim();
  const buyerContact=$("buyerContact").value.trim();
  if(!playerId||!buyerContact||(currentGame==="ml"&&!zoneId)){showToast("សូមបំពេញព័ត៌មានដែលមានសញ្ញា *");return;}
  const order={
    id:makeOrderId(), createdAt:new Date().toISOString(), game:GAME_NAMES[currentGame],
    gameKey:currentGame, packageName:selectedPackage.name, price:selectedPackage.price,
    playerId, zoneId, buyerContact, status:"Pending payment"
  };
  const orders=getOrders(); orders.unshift(order); saveOrders(orders);
  currentOrderId=order.id;
  renderPayment(order);
  $("paymentDialog").showModal();
});
function renderPayment(order){
  const settings=getSettings();
  const qrHtml=settings.qr.phillip
    ? `<div class="qr-placeholder"><b>Phillip Bank • KHQR</b><br><img src="${safe(settings.qr.phillip)}" alt="Phillip Bank payment QR"><p>គណនី៖ ${safe(settings.paymentNote||"Touch Sokunthea")}</p></div>`
    : `<div class="qr-placeholder"><b>QR Phillip Bank មិនទាន់កំណត់</b><p>សូមកំណត់រូប QR ពិតក្នុង CONFIG មុនទទួលការទូទាត់។</p></div>`;
  const message=`Order: ${order.id}\nGame: ${order.game}\nPackage: ${order.packageName}\nAmount: ${formatPrice(order.price)}\nPlayer ID: ${order.playerId}${order.zoneId?"\nZone ID: "+order.zoneId:""}\nContact: ${order.buyerContact}\nStatus: ${order.status}`;
  const tg=telegramUrl(message);
  $("paymentContent").innerHTML=`
    <p class="small-note">សូមពិនិត្យឈ្មោះអ្នកទទួល និងចំនួនប្រាក់មុនផ្ទេរ។ បន្ទាប់មកផ្ញើ Order ID និងភស្តុតាងទូទាត់ទៅ Admin។ ការបញ្ជាទិញមិនទាន់បានបញ្ជាក់ជោគជ័យទេ។</p>
    <div class="order-id">${safe(order.id)}</div>
    <div class="summary-line"><span>ហ្គេម</span><b>${safe(order.game)}</b></div>
    <div class="summary-line"><span>កញ្ចប់</span><b>${safe(order.packageName)}</b></div>
    <div class="summary-total"><span>ត្រូវបង់</span><b>${formatPrice(order.price)}</b></div>
    ${qrHtml}
    <div class="modal-actions"><button class="secondary-btn" id="copyOrder">ចម្លង Order ID</button><button class="primary-btn" id="copyDetails">ចម្លងព័ត៌មាន</button></div>
    <div class="modal-actions">${tg?`<a class="telegram-btn" href="${tg}" target="_blank" rel="noopener">ផ្ញើទៅ Telegram</a>`:`<button class="secondary-btn" id="telegramMissing">កំណត់ Telegram របស់ហាង</button>`}<button class="secondary-btn" id="donePayment">បិទ</button></div>
    <p class="small-note">ស្ថានភាពបច្ចុប្បន្ន៖ Pending payment។ Admin ត្រូវផ្ទៀងផ្ទាត់ប្រាក់ដោយដៃ។</p>`;
  $("copyOrder").addEventListener("click",()=>copyText(order.id));
  $("copyDetails").addEventListener("click",()=>copyText(message));
  $("donePayment").addEventListener("click",()=>$("paymentDialog").close());
  const missing=$("telegramMissing"); if(missing)missing.addEventListener("click",()=>{ $("paymentDialog").close(); $("adminDialog").showModal(); });
}
async function copyText(text){
  try{await navigator.clipboard.writeText(text);showToast("បានចម្លងរួចរាល់");}
  catch{const area=document.createElement("textarea");area.value=text;document.body.append(area);area.select();document.execCommand("copy");area.remove();showToast("បានចម្លងរួចរាល់");}
}
$("closePayment").addEventListener("click",()=>$("paymentDialog").close());
$("openAdmin").addEventListener("click",()=>{ $("adminPin").value=""; $("adminLogin").classList.remove("hidden"); $("adminContent").classList.add("hidden"); $("adminDialog").showModal(); });
$("closeAdmin").addEventListener("click",()=>$("adminDialog").close());
$("adminLoginBtn").addEventListener("click",()=>{
  if($("adminPin").value!==CONFIG.adminPin){showToast("PIN មិនត្រឹមត្រូវ");return;}
  $("adminLogin").classList.add("hidden"); $("adminContent").classList.remove("hidden");
  loadSettingsForm(); renderAdminOrders();
});
function renderAdminOrders(){
  const orders=getOrders();
  if(!orders.length){$("adminOrders").innerHTML='<div class="empty-state">មិនទាន់មានការបញ្ជាទិញក្នុង browser នេះទេ។</div>';return;}
  $("adminOrders").innerHTML=orders.map(o=>`
    <div class="admin-order"><h4>${safe(o.id)}</h4>
    <p><b>${safe(o.game)} — ${safe(o.packageName)}</b> • ${formatPrice(o.price)}</p>
    <p>Player ID: ${safe(o.playerId)} ${o.zoneId?"• Zone: "+safe(o.zoneId):""}</p>
    <p>ទំនាក់ទំនង: ${safe(o.buyerContact)}</p>
    <p>ពេលវេលា: ${safe(new Date(o.createdAt).toLocaleString())}</p>
    <label for="status-${safe(o.id)}">ស្ថានភាព</label>
    <select id="status-${safe(o.id)}" data-status="${safe(o.id)}">
      ${["Pending payment","Payment received","Processing","Completed","Cancelled"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}
    </select></div>`).join("");
  $("adminOrders").querySelectorAll("[data-status]").forEach(select=>select.addEventListener("change",()=>{
    const list=getOrders();const item=list.find(o=>o.id===select.dataset.status);
    if(item){item.status=select.value;saveOrders(list);showToast("បានប្តូរស្ថានភាព");}
  }));
}
function loadSettingsForm(){
  const s=getSettings();$("phillipQr").value=s.qr.phillip||"";
  $("telegramUser").value=s.telegramUsername||"";$("storeNote").value=s.paymentNote||"";
}
$("saveSettings").addEventListener("click",()=>{
  const old=getSettings();
  const s={qr:{phillip:$("phillipQr").value.trim()},telegramUsername:$("telegramUser").value.trim().replace(/^@/,""),paymentNote:$("storeNote").value.trim()};
  saveSettings(s);showToast("រក្សាទុកក្នុង browser នេះរួចរាល់");
});
$("exportOrders").addEventListener("click",()=>{
  const orders=getOrders();if(!orders.length){showToast("គ្មាន Order សម្រាប់ Export");return;}
  const headers=["id","createdAt","game","packageName","price","playerId","zoneId","buyerContact","status"];
  const csv=[headers.join(","),...orders.map(o=>headers.map(k=>`"${String(o[k]??"").replace(/"/g,'""')}"`).join(","))].join("\r\n");
  const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8;"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="kh-gaming-orders.csv";a.click();URL.revokeObjectURL(url);
});
$("telegramContact").addEventListener("click",e=>{
  const user=(getSettings().telegramUsername||"").replace(/^@/,"").trim();
  if(!user||user==="YOUR_TELEGRAM"){e.preventDefault();showToast("សូមកំណត់ Telegram username ក្នុង script.js");return;}
  $("telegramContact").href="https://t.me/"+encodeURIComponent(user);
});
$("year").textContent=new Date().getFullYear();
renderPackages();
