# KH GAMING STORE

Responsive static top-up storefront for Free Fire, Mobile Legends, and Roblox. Designed for GitHub Pages.

## Files
- `index.html` — page layout and forms
- `style.css` — responsive gaming-store design
- `script.js` — demo package data, order flow, QR settings, local demo admin

## Publish with an Android phone
1. Sign in at https://github.com/ and create a **public** repository named `kh-gaming-store`.
2. Add the three files from this folder to the repository root (`index.html`, `style.css`, `script.js`).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for GitHub Pages to publish. Your site URL will look like `https://YOUR-USERNAME.github.io/kh-gaming-store/`.

## Configure before showing customers
Open `script.js` and edit the `CONFIG` object:
- `adminPin`: demo PIN only. It is visible to anyone who views source and is NOT secure.
- `telegramUsername`: your Telegram username without `@`.
- `paymentNote`: the displayed receiver/store name.
- `qr.phillip`: path/URL for the Phillip Bank QR image (default: `assets/phillip-qr.jpg`).
- `packages`: package names and prices. The included prices are sample values; verify them with your supplier.

## Important limitations
This is a front-end demo. Orders/settings use browser `localStorage`, which means:
- Orders are stored only in the browser/device that created them.
- The Admin panel only sees orders stored in that same browser.
- The demo PIN is not secure because JavaScript is public.
- Admin settings saved in the browser do not update other customers' browsers.
- There is no automatic payment verification or game top-up API.
- A Telegram link can open a chat but cannot securely send a bot message without a properly configured bot/backend.

Before accepting real payments, connect a trusted backend/database and secure admin authentication. Verify payment in your own banking app; never trust a screenshot alone. Do not collect game passwords, PINs, or OTPs.


## Phillip Bank QR image
The `assets/phillip-qr.jpg` file is cropped from the QR screenshot provided in this conversation. Because it will be public on GitHub Pages, only publish it if you are comfortable displaying the account name and payment QR publicly.


## Price setting
All packages are currently set to **US$0.10 per package**. Prices are displayed in USD. This is a demo price; confirm your actual costs and payment arrangement before selling.
